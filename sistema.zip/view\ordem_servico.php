<div class='max-w-md mx-auto bg-white rounded-lg shadow-md p-6'>
    <h1 class='text-2xl font-bold text-gray-800 mb-6 text-center'>Cadastro de ordem_servico</h1>
    <form action="../control/ordem_servicoControl.php?a=1" method="post">
        
            <div class='mb-4'>
                <label for='id' class='block text-gray-700 text-sm font-bold mb-2'>id</label>
                <input type='text' name='id' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='descricao_problema' class='block text-gray-700 text-sm font-bold mb-2'>descricao_problema</label>
                <input type='text' name='descricao_problema' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='data_abertura' class='block text-gray-700 text-sm font-bold mb-2'>data_abertura</label>
                <input type='text' name='data_abertura' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='prazo_estimado' class='block text-gray-700 text-sm font-bold mb-2'>prazo_estimado</label>
                <input type='text' name='prazo_estimado' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='status' class='block text-gray-700 text-sm font-bold mb-2'>status</label>
                <input type='text' name='status' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='id_cliente' class='block text-gray-700 text-sm font-bold mb-2'>id_cliente</label>
                <input type='text' name='id_cliente' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
            <div class='mb-4'>
                <label for='id_tipo_servico' class='block text-gray-700 text-sm font-bold mb-2'>id_tipo_servico</label>
                <input type='text' name='id_tipo_servico' class='shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline'>
            </div>
        <div class='flex space-x-4'>
            <button type="submit" class='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded flex-1'>
                Salvar
            </button>
            <button type="button" onclick="voltarMenu()" class='bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded flex-1'>
                Voltar
            </button>
        </div>
    </form>
</div>