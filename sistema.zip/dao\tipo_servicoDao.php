<?php
require_once("../model/conexao.php");
class Tipo_servicoDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO tipo_servico (id, nome) VALUES (?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();

    $stmt->execute([$id,$nome]);
}
function listaGeral(){
    $sql = "select * from tipo_servico";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
function excluir($id){
    $sql = "delete from tipo_servico where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaTipo_servico.php");
}
    
}
?>