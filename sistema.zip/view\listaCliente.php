<div class='max-w-6xl mx-auto bg-white rounded-lg shadow-md p-6'>
    <h1 class='text-2xl font-bold text-gray-800 mb-6 text-center'>Lista de cliente</h1>
    <?php
    require_once("../dao/clienteDao.php");
    $dao = new clienteDAO();
    $dados = $dao->listaGeral();
    
    if (!empty($dados)) {
        echo "<div class='overflow-x-auto'>";
        echo "<table class='min-w-full bg-white rounded-lg overflow-hidden'>";
        echo "<thead class='bg-gray-800 text-white'>";
        echo "<tr>";
        foreach($dados[0] as $key => $value) {
            echo "<th class='py-3 px-4 text-left'>".ucfirst($key)."</th>";
        }
        echo "<th class='py-3 px-4 text-left'>Ações</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody class='text-gray-700'>";
        
        foreach($dados as $index => $dado) {
            $rowClass = $index % 2 === 0 ? 'bg-gray-50' : 'bg-white';
            echo "<tr class='{$rowClass} hover:bg-gray-100'>";
            echo "<td class='py-2 px-4 border-b'>{$dado['id']}</td>";
echo "<td class='py-2 px-4 border-b'>{$dado['nome']}</td>";
echo "<td class='py-2 px-4 border-b'>{$dado['telefone']}</td>";
echo "<td class='py-2 px-4 border-b'>{$dado['email']}</td>";

            echo "<td class='py-2 px-4 border-b'>";
            echo "<a href='../control/clienteControl.php?id={$dado['id']}&a=2' class='bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-sm mr-2' onclick='return confirm(\\`Confirma exclusão?`\\)'>Excluir</a>";
            echo "<button class='bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm'>Alterar</button>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p class='text-gray-600 text-center'>Nenhum registro encontrado.</p>";
    }
    ?>
    <div class='mt-6 flex space-x-4 justify-center'>
        <button onclick="carregarPagina('cliente.php')" class='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-6 rounded'>
            Novo Cadastro
        </button>
        <button onclick="voltarMenu()" class='bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-6 rounded'>
            Voltar ao Menu
        </button>
    </div>
</div>