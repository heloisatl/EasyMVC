<?php
require_once("../model/ordem_servico.php");
require_once("../dao/ordem_servicoDao.php");
class Ordem_servicoControl {
    private $ordem_servico;
    private $acao;
    private $dao;
    public function __construct(){
       $this->ordem_servico=new Ordem_servico();
      $this->dao=new Ordem_servicoDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->ordem_servico->setId($_POST['id']);
		$this->ordem_servico->setDescricao_problema($_POST['descricao_problema']);
		$this->ordem_servico->setData_abertura($_POST['data_abertura']);
		$this->ordem_servico->setPrazo_estimado($_POST['prazo_estimado']);
		$this->ordem_servico->setStatus($_POST['status']);
		$this->ordem_servico->setId_cliente($_POST['id_cliente']);
		$this->ordem_servico->setId_tipo_servico($_POST['id_tipo_servico']);
		
        $this->dao->inserir($this->ordem_servico);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Ordem_servico $ordem_servico){}
    function buscaTodos(){}

}
new Ordem_servicoControl();
?>