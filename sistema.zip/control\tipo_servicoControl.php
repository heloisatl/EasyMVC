<?php
require_once("../model/tipo_servico.php");
require_once("../dao/tipo_servicoDao.php");
class Tipo_servicoControl {
    private $tipo_servico;
    private $acao;
    private $dao;
    public function __construct(){
       $this->tipo_servico=new Tipo_servico();
      $this->dao=new Tipo_servicoDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->tipo_servico->setId($_POST['id']);
		$this->tipo_servico->setNome($_POST['nome']);
		
        $this->dao->inserir($this->tipo_servico);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Tipo_servico $tipo_servico){}
    function buscaTodos(){}

}
new Tipo_servicoControl();
?>