<?php
require_once("../model/conexao.php");
class ClienteDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO cliente (id, nome, telefone, email) VALUES (?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();
$telefone=$obj->getTelefone();
$email=$obj->getEmail();

    $stmt->execute([$id,$nome,$telefone,$email]);
}
function listaGeral(){
    $sql = "select * from cliente";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
function excluir($id){
    $sql = "delete from cliente where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaCliente.php");
}
    
}
?>