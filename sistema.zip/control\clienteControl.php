<?php
require_once("../model/cliente.php");
require_once("../dao/clienteDao.php");
class ClienteControl {
    private $cliente;
    private $acao;
    private $dao;
    public function __construct(){
       $this->cliente=new Cliente();
      $this->dao=new ClienteDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->cliente->setId($_POST['id']);
		$this->cliente->setNome($_POST['nome']);
		$this->cliente->setTelefone($_POST['telefone']);
		$this->cliente->setEmail($_POST['email']);
		
        $this->dao->inserir($this->cliente);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Cliente $cliente){}
    function buscaTodos(){}

}
new ClienteControl();
?>