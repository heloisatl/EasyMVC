<!DOCTYPE html>
<html>
<head>
    <title>EasyMVC - Sistema</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { display: flex; height: 100vh; margin: 0; }
        nav { width: 250px; background: #127078; padding: 20px; color: white; }
        nav button { display: block; margin-bottom: 10px; padding: 10px; width: 100%;
                     text-align: left; background: #1da1ad; border-radius: 5px; }
        nav button:hover { background: #0c4c4f; }
        #conteudo { flex: 1; padding: 20px; overflow-y: auto; background: #f0f0f0; }
    </style>
</head>
<body>
    <nav>
        <h2 class="text-xl font-bold mb-4">Menu</h2>
        
            <button onclick="carregarPagina('cliente.php')">📝 Cadastrar Cliente</button>
            <button onclick="carregarPagina('listaCliente.php')">📋 Listar Cliente</button>
        
            <button onclick="carregarPagina('ordem_servico.php')">📝 Cadastrar Ordem_servico</button>
            <button onclick="carregarPagina('listaOrdem_servico.php')">📋 Listar Ordem_servico</button>
        
            <button onclick="carregarPagina('tipo_servico.php')">📝 Cadastrar Tipo_servico</button>
            <button onclick="carregarPagina('listaTipo_servico.php')">📋 Listar Tipo_servico</button>
        
    </nav>

    <div id="conteudo">
        <h1 class="text-2xl font-bold">Bem-vindo ao sistema!</h1>
        <p>Selecione uma opção no menu.</p>
    </div>

    <script>
        function carregarPagina(url) {
            fetch(url)
                .then(res => res.text())
                .then(html => { document.getElementById('conteudo').innerHTML = html; })
                .catch(() => { document.getElementById('conteudo').innerHTML = "<p>Erro ao carregar.</p>"; });
        }
        function voltarMenu() {
            document.getElementById('conteudo').innerHTML = "<h1 class='text-2xl font-bold'>Bem-vindo ao sistema!</h1><p>Selecione uma opção no menu.</p>";
        }
    </script>
</body>
</html>