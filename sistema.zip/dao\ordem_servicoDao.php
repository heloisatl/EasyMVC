<?php
require_once("../model/conexao.php");
class Ordem_servicoDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO ordem_servico (id, descricao_problema, data_abertura, prazo_estimado, status, id_cliente, id_tipo_servico) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$descricao_problema=$obj->getDescricao_problema();
$data_abertura=$obj->getData_abertura();
$prazo_estimado=$obj->getPrazo_estimado();
$status=$obj->getStatus();
$id_cliente=$obj->getId_cliente();
$id_tipo_servico=$obj->getId_tipo_servico();

    $stmt->execute([$id,$descricao_problema,$data_abertura,$prazo_estimado,$status,$id_cliente,$id_tipo_servico]);
}
function listaGeral(){
    $sql = "select * from ordem_servico";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
function excluir($id){
    $sql = "delete from ordem_servico where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaOrdem_servico.php");
}
    
}
?>